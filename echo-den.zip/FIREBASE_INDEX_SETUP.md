// src/firebase.ts
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// 🔹 Firebase project configuration
const firebaseConfig = {
   apiKey: "AIzaSyCoFsT1x5XZOtJlW9YqjkZrBETsORtjjIs",
  authDomain: "sleepvision-2cf4e.firebaseapp.com",
  projectId: "sleepvision-2cf4e",
  storageBucket: "sleepvision-2cf4e.firebasestorage.app",
  messagingSenderId: "1067576043258",
  appId: "1:1067576043258:web:6648b5f32c77bd7fa90b43",
  measurementId: "G-VKZTXCTLE9"
};

// 🔧 Initialize Firebase app
const app = initializeApp(firebaseConfig);

// 🔧 Initialize Firebase services
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);
